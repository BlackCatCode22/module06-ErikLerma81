package Pack;

class Tiger extends Animal {


    public Tiger(String name, int age,String sex ,String color, int weight, String season, String origin, String id, String birthday) {
        // Assuming 'Tiger' as the default species for this subclass
        super(name, "Tiger",age, sex, color, weight, season, origin, id, birthday);
    }


}