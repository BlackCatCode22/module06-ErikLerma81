package Pack;

class Hyena extends Animal {



    public Hyena(String name, int age,String sex ,String color, int weight, String season, String origin, String id, String birthday) {
        // Assuming 'Hyena' as the default species for this subclass
        super(name,"Hyena",age, sex, color, weight, season, origin, id, birthday);
    }


}

