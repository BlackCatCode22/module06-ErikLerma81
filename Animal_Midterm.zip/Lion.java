package Pack;

class Lion extends Animal {


    public Lion(String name, int age,String sex ,String color, int weight, String season, String origin, String id, String birthday) {
        // Assuming 'Lion' as the default species for this subclass
        super(name, "Lion",age, sex, color, weight, season, origin, id, birthday);
    }


}
