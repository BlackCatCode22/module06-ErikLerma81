package Pack;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;


public class Main {
    public static void main(String[] args) {


        ArrayList<Animal> animals = new ArrayList<>();

        int bearIndex = 0;
        int tigerIndex = 0;
        int lionIndex = 0;
        int hyenaIndex = 0;

        String Name = "";
        String Species = "";
        int Age = 0;
        String sex = "";
        String color = "";
        int weight;
        String season = "";
        String origin = "";
        String birthday = "";

        String id;


        String filePath = ("C:/Users/ErikL/OneDrive/Desktop/arrivingAnimals.txt");
        File file = new File(filePath);


        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();


                String[] parts = line.split(", ");


                /*                                                        */
                String ageAndSpecies = parts[0];


                String[] theParts = ageAndSpecies.split(" ");

                Age = Integer.parseInt(theParts[0]);
                sex = theParts[3].toLowerCase();
                Species = theParts[4].toLowerCase();


                /*                                                        */

                String seasonBorn = parts[1];

                String[] theParts2 = seasonBorn.split(" ");

                if (theParts2[0].equals("unknown")){
                    season = "unknown";
                }
                else{
                    season = theParts2[2];
                }



                /*                                                        */

                String animalColor = parts[2];

                String[] theParts3 = animalColor.split("color");

                color = theParts3[0];



                /*                                                        */

                String animalWeight = parts[3];

                String[] theParts4 = animalWeight.split(" ");

                weight = Integer.parseInt(theParts4[0]);

                /*                                                        */

                String animalOriginPark = parts[4];

                String animalOriginCountry = parts[5];

                String[] theParts5 = animalOriginPark.split("from");

                origin = theParts5[1] + ", " +parts[5];


                switch (Species) {
                    case "hyena" -> {
                        Name = getName("Hyena", hyenaIndex);
                        id = genUniqeID(hyenaIndex + 1, Species);
                        birthday = genBirthDay(season);
                        hyenaIndex++;
                        Hyena newHyena = new Hyena(Name, Age, sex, color, weight, season, origin, id, birthday);
                        animals.add(newHyena);
                    }
                    case "tiger" -> {
                        Name = getName("Tiger", tigerIndex);
                        id = genUniqeID(tigerIndex + 1, Species);
                        birthday = genBirthDay(season);
                        tigerIndex++;
                        Tiger newTiger = new Tiger(Name, Age, sex, color, weight, season, origin, id,birthday);
                        animals.add(newTiger);
                    }
                    case "bear" -> {
                        Name = getName("Bear", bearIndex);
                        id = genUniqeID(bearIndex + 1, Species);
                        birthday = genBirthDay(season);
                        bearIndex++;
                        Bear newBear = new Bear(Name, Age, sex, color, weight, season, origin, id,birthday);
                        animals.add(newBear);
                    }
                    case "lion"-> {
                        Name = getName("Lion", lionIndex);
                        id = genUniqeID(lionIndex + 1, Species);
                        birthday = genBirthDay(season);
                        lionIndex++;
                        Lion newLion = new Lion(Name, Age, sex, color, weight, season, origin, id,birthday);
                        animals.add(newLion);
                    }

                }




            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
            e.printStackTrace();
        }

        for (Animal animal : animals){


            System.out.println( animal.getID() + "| Name: " + animal.getName() + ", Birthday: " + animal.getBirthday() + ", Color:" + animal.getColor() + ", Sex: " +animal.getSex() + ", Weight:" + animal.getWeight() + ", From:" + animal.getOrigin() + "\n");
        }

        System.out.println("Total Animals: " + Animal.TotalAnimals);


        try {
            FileWriter fileWriter = new FileWriter("C:/Users/ErikL/OneDrive/Desktop/zooPopulation.txt");
            fileWriter.write("Hyena Population: " + hyenaIndex + "\n");
            fileWriter.write("Bear Population: " + bearIndex+ "\n");
            fileWriter.write("Lion Population: " + lionIndex+ "\n");
            fileWriter.write("Tiger Population: " + tigerIndex+ "\n");
            fileWriter.write("Total Population: " + Animal.TotalAnimals+ "\n\n");

            String[] AnimalsTypes = {"HYENA", "LION", "TIGER", "BEAR"};
            int index = 0;
            int goal = 0;
            int num = 0;

            for (Animal animal : animals){

            if (num == 0){
                    fileWriter.write(AnimalsTypes[index] + "\n");
                    num++;
            }

            if (goal == 4){
                index++;
                fileWriter.write(AnimalsTypes[index] + "\n");
                goal = 0;
            }
            else{

            }

            fileWriter.write( animal.getID() + "| Name: " + animal.getName() + ", Birthday: " + animal.getBirthday() + ", Color:" + animal.getColor() + ", Sex: " +animal.getSex() + ", Weight:" + animal.getWeight() + ", From:" + animal.getOrigin() + "\n\n");

            goal++;
            }

            fileWriter.close();
            System.out.println("Successfully wrote to the file.");
        }
        catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


    }

    public static String getName(String name, int index) {
        String returnName = "1";
        String filePath = ("C:/Users/ErikL/OneDrive/Desktop/animalNames.txt");
        File file = new File(filePath);

        try (Scanner scanner = new Scanner(file)) {

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] temp = line.split(" ");

                if (temp[0].equals(name)) {

                    line = scanner.nextLine();
                    line = scanner.nextLine();
                    String[] names = line.split(" ");

                    names[index] = names[index].replace(",", "");
                    returnName = names[index];

                    break; // Exit the loop once the name is found
                }
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
            e.printStackTrace();
        }
     return returnName;
    }


    public static String genBirthDay(String season){
        String[] Winter = {"December", "January", "February"};
        String[] Fall = {"September", "October", "November"};
        String[] Spring = {"April", "March", "May"};

        Random rand = new Random();
        int index = rand.nextInt(3);

        String Month = "";
        int day;
        String Day = " ";

        if (season.equals("unknown")){
            return "UNKNOWN";
        }

        if (season.equals("winter")){
            Month = Winter[index];

            if (Month.equals("December") || Month.equals("January")){
                day = rand.nextInt(31) + 1;
                Day = String.valueOf(day);
            }
            else {
                day = rand.nextInt(29) + 1;
                Day = String.valueOf(day);
            }

        }
        else if (season.equals("spring")){
            Month = Spring[index];

            if (Month.equals("March") || Month.equals("May")){
                day = rand.nextInt(31) + 1;
                Day = String.valueOf(day);
            }
            else {
                day = rand.nextInt(30) + 1;
                Day = String.valueOf(day);
            }


        }
        else if (season.equals("fall")){
            Month = Fall[index];

            if (Month.equals("September") || Month.equals("November")){
                day = rand.nextInt(30) + 1;
                Day = String.valueOf(day);
            }

            else {
                day = rand.nextInt(31) + 1;
                Day = String.valueOf(day);
            }
        }

        return Month + " " + Day;
    }

    public static String genUniqeID(int number, String animal){
        String FormatedNum = String.format("%02d", number);

        String temp = animal.substring(0,2);

        return  temp + FormatedNum;

    }
}

