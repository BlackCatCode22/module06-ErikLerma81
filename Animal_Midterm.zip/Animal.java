package Pack;

public class Animal {
    private String Name;
    private int Age;
    private String Species;
    private String Sex;
    private String Color;
    private int Weight;
    private String Season;
    private String Origin;
    private String ID;
    private String Birthday;

    public static int TotalAnimals = 0;

    public Animal(String TheName,String TheSpecies, int TheAge, String TheSex, String TheColor, int TheWeight, String TheSeason, String TheOrigin, String TheID, String Thebirthday){
        this.Name = TheName;
        this.Age = TheAge;
        this.Species = TheSpecies;
        this.Sex = TheSex;
        this.Color = TheColor;
        this.Weight = TheWeight;
        this.Season = TheSeason;
        this.Origin = TheOrigin;
        this.ID = TheID;
        this.Birthday = Thebirthday;
        TotalAnimals++;
    }



    public String getName(){
        return Name;
    }

    public int getAge(){
        return Age;
    }

    public String getSpecies(){
        return Species;

    }

    public String getID(){
        return ID;
    }

    public String getSex(){
        return Sex;
    }

    public String getColor(){
        return Color;
    }

    public int getWeight(){
        return Weight;
    }

    public String getSeason(){
        return Season;
    }

    public String getOrigin(){
        return Origin;
    }

    public String getBirthday(){
        return Birthday;
    }

}
