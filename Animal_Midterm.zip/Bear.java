package Pack;

class Bear extends Animal {


    public Bear(String name, int age,String sex ,String color, int weight, String season, String origin, String id, String birthday) {
        // Assuming 'Bear' as the default species for this subclass
        super(name, "Bear",age, sex, color, weight, season, origin, id, birthday);
    }


}

